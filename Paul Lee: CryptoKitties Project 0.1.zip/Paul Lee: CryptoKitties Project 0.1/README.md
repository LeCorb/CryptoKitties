# academy-kitties-template
A starter template for bootcamp students building the cryptokitty clone.
