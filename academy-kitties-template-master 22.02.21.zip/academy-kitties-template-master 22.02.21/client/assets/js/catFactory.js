
//Random color
function getColor() {
    var randomColor = Math.floor(Math.random() * 16777215).toString(16);
    return randomColor
}

function genColors(){
    var colors = []
    for(var i = 10; i < 99; i ++){
      var color = getColor()
      colors[i] = color
    }
    return colors
}

//This function code needs to modified so that it works with Your cat code.
function headColor(color,code) {
    $('.cat__head, .cat__chest').css('background', '#' + color)  //This changes the color of the cat
    $('#headcode').html('code: '+code) //This updates text of the badge next to the slider
    $('#dnabody').html(code) //This updates the body color part of the DNA that is displayed below the cat
}

function mouthColor(color,code) {
    $('.cat__mouth-contour, .cat__chest_inner, .cat__tail').css('background', '#' + color)  //This changes the color of the cat
    $('#mouthcode').html('code: '+code) //This updates text of the badge next to the slider
    $('#dnamouth').html(code) //This updates the body color part of the DNA that is displayed below the cat
}

function eyesColor(color,code) {
    $('.cat__eye--left, .cat__eye--right').css('background', '#' + color)  //This changes the color of the cat
    $('#eyescode').html('code: '+code) //This updates text of the badge next to the slider
    $('#dnaeyes').html(code) //This updates the body color part of the DNA that is displayed below the cat
}

function earsColor(color,code) {
    $('.cat__ear--right, .cat__ear--left, .cat__paw-left, .cat__paw-right').css('background', '#' + color)  //This changes the color of the cat
    $('#earscode').html('code: '+code) //This updates text of the badge next to the slider
    $('#dnaears').html(code) //This updates the body color part of the DNA that is displayed below the cat
}

function decorationMidColor(color,code) {

    $('.cat__head-dots').css('background', '#' + color)  //This changes the color of the dots
    $('#decorationmidcode').html('code: '+ code) //This updates text of the badge next to the slider
    $('#dnadecorationMid').html(code) //This updates the body color part of the DNA that is displayed below the cat
    console.log(code)
    console.log(color)
}

function decorationSidesColor(color,code) {

    $('.cat__head-dots_first, .cat__head-dots_second').css('background', '#' + color)  //This changes the color of the cat
    $('#decorationsidescode').html('code: '+ code) //This updates text of the badge next to the slider
    $('#dnadecorationSides').html(code) //This updates the body color part of the DNA that is displayed below the cat
    console.log(code)
    console.log(color)
}




//###################################################
//Functions below will be used later on in the project
//###################################################
function eyeVariation(num) {

    $('#dnashape').html(num)
    switch (num) {
        case 1:
            normalEyes()
            $('#eyeName').html('Basic')
            console.log(num)
            break

        case 2:
            normalEyes()
            $('#eyeName').html('Nice')
            console.log(num)
            return eyesType1()
            break

        case 3:
            normalEyes()
            $('#eyeName').html('Cool')
            console.log(num)
            return eyesType2()
            break

        case 4:
            normalEyes()
            $('#eyeName').html('Uh Oh')
            console.log(num)
            return eyesType3()
            break

        case 5:
            normalEyes()
            $('#eyeName').html('Aha')
            console.log(num)
            return eyesType4()
            break

        case 6:
            normalEyes()
            $('#eyeName').html('No Way')
            console.log(num)
            return eyesType5()
            break

        case 7:
            normalEyes()
            $('#eyeName').html('No Bodder')
            console.log(num)
            return eyesType6()
            break

default:

console.log("Not 1 or 2")
break

    }
}

function decorationVariation(num) {
    $('#dnadecoration').html(num)
    switch (num) {
        case 1:
            $('#decorationName').html('Basic')
            console.log(num)
            normaldecoration()
            break

        case 2:
            $('#decorationName').html('Crazy')
            console.log(num)

            decoration1()
            break

        case 3:
            $('#decorationName').html('Psycho')
            console.log(num)

            decoration2()
            break


    }
}

async function normalEyes() {
    await $('.cat__eye').find('span').css('border', 'none')
}
async function eyesType1() {
    await $('.cat__eye').find('span').css('border-top', '15px solid')
}
async function eyesType2() {
    await $('.cat__eye').find('span').css('border-bottom', '15px solid')
}
async function eyesType3() {
    await $('.cat__eye').find('span').css('border-left', '15px solid')
}
async function eyesType4() {
    await $('.cat__eye').find('span').css('border-right', '15px solid')
}
async function eyesType5() {
    await $('.cat__eye').find('span').css('border-top', '25px solid')
}
async function eyesType6() {
    await $('.cat__eye').find('span').css('border-left', '23px solid')
}


async function normaldecoration() {
    //Remove all style from other decorations
    //In this way we can also use normalDecoration() to reset the decoration style
    await $('.cat__head-dots').css({ "transform": "rotate(0deg)", "height": "48px", "width": "14px", "top": "1px", "border-radius": "0 0 50% 50%" })
    await $('.cat__head-dots_first').css({ "transform": "rotate(0deg)", "height": "35px", "width": "14px", "top": "1px", "border-radius": "50% 0 50% 50%", "left": "-20px"})
    await $('.cat__head-dots_second').css({ "transform": "rotate(0deg)", "height": "35px", "width": "14px", "top": "1px", "border-radius": "0 50% 50% 50%","left": "20px" })
}

async function decoration1() {
    //Remove all style from other decorations
    //In this way we can also use normalDecoration() to reset the decoration style
    normaldecoration()
    await $('.cat__head-dots').css({ "transform": "rotate(0deg)", "height": "48px", "width": "14px", "top": "1px", "border-radius": "0 0 50% 50%" })
    await $('.cat__head-dots_first').css({ "transform": "rotate(20deg)", "height": "35px", "width": "14px", "top": "1px", "border-radius": "50% 0 50% 50%", "left": "-30px" })
    await $('.cat__head-dots_second').css({ "transform": "rotate(-20deg)", "height": "35px", "width": "14px", "top": "1px", "border-radius": "0 50% 50% 50%", "left": "30px"})
}

async function decoration2() {
    //Remove all style from other decorations
    //In this way we can also use normalDecoration() to reset the decoration style

    await $('.cat__head-dots').css({ "transform": "rotate(0deg)", "height": "48px", "width": "14px", "top": "1px", "border-radius": "0 0 50% 50%" })
    await $('.cat__head-dots_first').css({ "transform": "rotate(40deg)", "height": "35px", "width": "18px", "top": "1px", "border-radius": "50% 0 50% 50%", "left": "-50px" })
    await $('.cat__head-dots_second').css({ "transform": "rotate(-40deg)", "height": "35px", "width": "18px", "top": "1px", "border-radius": "0 50% 50% 50%", "left": "45px"})
}
